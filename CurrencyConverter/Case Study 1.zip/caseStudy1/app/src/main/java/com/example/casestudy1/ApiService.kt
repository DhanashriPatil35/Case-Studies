package com.example.casestudy1


import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url


interface ApiService {
    @GET("latest?")
    fun getUsers(@Query("base") _base: String,
                 @Query("symbols") _symbol: String) : Call<MyData>
}