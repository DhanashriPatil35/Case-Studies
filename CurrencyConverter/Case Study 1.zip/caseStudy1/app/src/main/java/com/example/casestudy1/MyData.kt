package com.example.casestudy1

import com.google.gson.annotations.SerializedName

data class MyData(
    val base: String,
    val date: String,
    @SerializedName("rates")
    val myRate : rate
)

data class rate(
    val INR : Double
)