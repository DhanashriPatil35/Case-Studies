package com.example.casestudy1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_conversion.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class Conversion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversion)

        conversion.setOnClickListener(){
            var myData = usd.text.toString()

            if(myData.isNotEmpty()){
                var data = usd.text.toString().toInt()
                val retrofit = Retrofit.Builder()
                    .baseUrl("https://api.exchangeratesapi.io/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()

                val api = retrofit.create(ApiService::class.java)

                api.getUsers("USD","INR").enqueue(object : Callback<MyData> {
                    override fun onFailure(call: Call<MyData>, t: Throwable) {
                        Log.d("failure", "OnFailure")
                    }

                    override fun onResponse(call: Call<MyData>, response: Response<MyData>) {
                        Log.d("success", "OnResponse")
                        println("------------------------")
                        var rate : Double
                        rate = response.body()?.myRate?.INR!!
                        var result : Double
                        result = data*rate
                        println("result: $result")

                        findViewById<TextView>(R.id.inrVal).setText("$result").toString()

                    }
                })
            }else{
                Toast.makeText(getApplicationContext(),"Please enter some USD", Toast.LENGTH_SHORT).show()
            }

        }
    }
}