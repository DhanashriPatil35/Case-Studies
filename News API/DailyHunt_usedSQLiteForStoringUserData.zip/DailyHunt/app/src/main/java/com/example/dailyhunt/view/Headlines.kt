package com.example.dailyhunt.view

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dailyhunt.R
import com.example.dailyhunt.adaptor.HeadlinesAdaptor
import com.example.dailyhunt.model.Article
import com.example.dailyhunt.networking.NewsRepository
import com.example.dailyhunt.sharedpreferences.MySharedPreference
import com.example.dailyhunt.viewmodel.NewsViewModel
import kotlinx.android.synthetic.main.activity_headlines.*


class Headlines : AppCompatActivity() {

    var myViewModel = NewsViewModel(NewsRepository())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_headlines)

        var intent = intent
        var myname = intent.getStringExtra("Name")
        var myemail = intent.getStringExtra("Email")

        profile.setOnClickListener(){
            var myIntent = Intent(this, UserProfileActivity ::class.java)
            myIntent.putExtra("Name",myname)
            myIntent.putExtra("Email",myemail)
            startActivity(myIntent)
        }

        logout.setOnClickListener(){
            var myPreferences = MySharedPreference()
            val sharedPreferences: SharedPreferences = getSharedPreferences(myPreferences.sharedPrefFile,
                Context.MODE_PRIVATE)
            myPreferences.setupSharedPreference(sharedPreferences)
            myPreferences.clearDetails()

            var myIntent = Intent(this, LoginActivity ::class.java)
            myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(myIntent)
        }

        userDatabase.setOnClickListener(){
            var myIntent = Intent(this, GetDBActivity ::class.java)
            startActivity(myIntent)
        }

        myViewModel.getNewsRepository()?.observe(this, Observer { responseArticle ->

            if (responseArticle != null) {
                showData(responseArticle.myArticles)
            }
            else{
                println(responseArticle)
            }
        }
        )
    }

    private fun showData(articles : ArrayList<Article>){
        myRecyclerView.apply {
            var myRecyclerView = findViewById<RecyclerView>(R.id.myRecyclerView) as RecyclerView
            myRecyclerView.layoutManager = LinearLayoutManager(this@Headlines, RecyclerView.VERTICAL,false)
            myRecyclerView.adapter = HeadlinesAdaptor(context,articles)
        }
    }
}