package com.example.dailyhunt.sharedpreferences

import android.content.SharedPreferences

class MySharedPreference() {

    val sharedPrefFile = "kotlinsharedpreference"

    var _sharedUsername : String? = null
    var _sharedPassword : String? = null
    var _sharedEmail : String? = null
    lateinit var editor: SharedPreferences.Editor

    fun setupSharedPreference(sharedPreferences : SharedPreferences){

        this.editor =  sharedPreferences.edit()

       if(sharedPreferences.getBoolean("saved",false)){
           this._sharedUsername = sharedPreferences.getString("username",null)
           this._sharedPassword = sharedPreferences.getString("password",null)
           this._sharedEmail = sharedPreferences.getString("email",null)
       }
    }

    fun saveDetails(username1 : String, password1 : String, email1 : String){
        editor.putString("username",username1)
        editor.putString("password",password1)
        editor.putString("email",email1)
        editor.putBoolean("saved", true)
        editor.apply()
    }

    fun clearDetails(){
        editor.clear()
        editor.commit()
    }
}