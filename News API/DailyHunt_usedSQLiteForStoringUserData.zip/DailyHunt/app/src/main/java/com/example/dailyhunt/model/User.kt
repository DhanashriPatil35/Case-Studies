package com.example.dailyhunt.model


//https://sqliteonline.com/
data class User(
    var userName : String,
    var email : String
)