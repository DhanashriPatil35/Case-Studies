package com.example.dailyhunt.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dailyhunt.R
import com.example.dailyhunt.database.MyDBHandler
import kotlinx.android.synthetic.main.activity_get_db.*

class GetDBActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_get_db)


        btnShowDatafromDb.setOnClickListener {
            tvDisplayName.text = ""
            val dbHandler = MyDBHandler(this, null)
            val cursor = dbHandler.getAllUsers()
            cursor!!.moveToFirst()

            tvDisplayName.append((cursor.getString(cursor.getColumnIndex(MyDBHandler.COLUMN_NAME))))
            tvDisplayName.append("\n")
            tvDisplayName.append((cursor.getString(cursor.getColumnIndex(MyDBHandler.COLUMN_EMAIL))))
            tvDisplayName.append("\n")
            tvDisplayName.append("\n")

            while (cursor.moveToNext()) {
                tvDisplayName.append((cursor.getString(cursor.getColumnIndex(MyDBHandler.COLUMN_NAME))))
                tvDisplayName.append("\n")
                tvDisplayName.append((cursor.getString(cursor.getColumnIndex(MyDBHandler.COLUMN_EMAIL))))
                tvDisplayName.append("\n")
                tvDisplayName.append("\n")
            }
        }
    }
}