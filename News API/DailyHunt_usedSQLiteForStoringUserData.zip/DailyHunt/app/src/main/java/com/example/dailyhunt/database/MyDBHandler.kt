package com.example.dailyhunt.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.dailyhunt.model.User

class MyDBHandler(context: Context,factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {

    companion object{
        val DATABASE_NAME : String = "user_database1.db"
        val DATABASE_VERSION : Int = 1
        val TABLE_NAME = "user"
        val COLUMN_NAME = "username"
        val COLUMN_EMAIL = "email"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_CONTACTS_TABLE = ("CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_NAME + " TEXT,"
                + COLUMN_EMAIL + " TEXT" + ")")
        db.execSQL(CREATE_CONTACTS_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)
        onCreate(db)
    }

    fun addUser(user : User ) {

        val values = ContentValues()
        values.put(COLUMN_NAME, user.userName)
        values.put(COLUMN_EMAIL, user.email)
        val db = this.writableDatabase
        /*println("--------deleting ------------")
        db.execSQL("DELETE FROM " + TABLE_NAME)*/
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun getAllUsers(): Cursor? {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME", null)
        //val selectQuery = "DELETE FROM $TABLE_NAME "
    }
}