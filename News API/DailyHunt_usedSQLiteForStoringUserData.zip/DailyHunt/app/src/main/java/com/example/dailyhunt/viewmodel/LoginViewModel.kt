package com.example.dailyhunt.viewmodel

import androidx.core.util.PatternsCompat
import java.util.regex.Pattern

class LoginViewModel {

    fun isValidUser(username:String, password: String, email: String): Boolean{
        if((username == "Admin" && password == "123") || (username == "Dhanashri Patil" && password == "111")){

            val pattern: Pattern = PatternsCompat.EMAIL_ADDRESS

            if(pattern.matcher(email).matches()){
                return true
            }else{
                return false
            }

        }else{
            return false
        }
    }
}