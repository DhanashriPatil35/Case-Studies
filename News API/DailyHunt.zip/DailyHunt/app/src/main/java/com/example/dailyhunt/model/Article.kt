package com.example.dailyhunt.model

import com.google.gson.annotations.SerializedName

data class Article(
    @SerializedName("source")
    val mySource : Source,
    val author : String,
    val title : String,
    val description : String,
    val publishedAt : String,
    val content : String,
    val url : String,
    val urlToImage : String
)