package com.example.dailyhunt.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dailyhunt.R
import com.example.dailyhunt.viewmodel.NewsViewModel.Companion.getNewsRepository
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dailyhunt.adaptor.HeadlinesAdaptor
import com.example.dailyhunt.model.Article
import kotlinx.android.synthetic.main.activity_headlines.*

class Headlines : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_headlines)

        getNewsRepository()?.observe(this, Observer { responseArticle ->

            if (responseArticle != null) {
                showData(responseArticle.myArticles)
            }
            else{
                println(responseArticle)
            }
        }
        )
    }

    private fun showData(articles : List<Article>){
        myRecyclerView.apply {
            var myRecyclerView = findViewById<RecyclerView>(R.id.myRecyclerView) as RecyclerView
            myRecyclerView.layoutManager = LinearLayoutManager(this@Headlines, RecyclerView.VERTICAL,false)
            myRecyclerView.adapter = HeadlinesAdaptor(context,articles)
        }
    }
}