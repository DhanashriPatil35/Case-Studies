package com.example.dailyhunt.networking

import androidx.lifecycle.MutableLiveData
import com.example.dailyhunt.model.Content
import com.example.dailyhunt.networking.RetrofitService.Companion.api
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NewsRepository {

    companion object{
        fun getArticles(_country: String, _category: String): MutableLiveData<Content> {

            val myData: MutableLiveData<Content> = MutableLiveData<Content>()

            api.getArticles(_country, _category).enqueue(object : Callback<Content> {
                override fun onFailure(call: Call<Content>, t: Throwable) {
                    println("onFailure method called...")
                    println(t)
                    myData.value = null
                }

                override fun onResponse(call: Call<Content>, response: Response<Content>) {
                    println("onResponse method called...")
                    myData.value = response.body()
                }
            })
            return myData
    }

    }
}