package com.example.dailyhunt.model

data class Source(
    val id : String,
    val name : String
)