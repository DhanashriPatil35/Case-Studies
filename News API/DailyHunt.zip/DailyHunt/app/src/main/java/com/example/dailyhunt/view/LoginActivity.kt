package com.example.dailyhunt.view

//import android.support.v7.app.AppCompatActivity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.dailyhunt.R
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val sharedPrefFile = "kotlinsharedpreference"

        val sharedPreferences: SharedPreferences = this.getSharedPreferences(sharedPrefFile,
            Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor =  sharedPreferences.edit()

        if(sharedPreferences.getBoolean("saved",false)){
            val _sharedUsername = sharedPreferences.getString("username",null)
            val _sharedPassword = sharedPreferences.getString("password",null)
            username.setText(_sharedUsername)
            password.setText(_sharedPassword)
        }

        save.setOnClickListener(){
            var username1 = username.text.toString()
            var password1 = password.text.toString()

            if((username1 == "Admin" && password1 == "123") || (username1 == "Dhanashri" && password1 == "111") ){

                if(saveDetails.isChecked()){

                    editor.putString("username",username1)
                    editor.putString("password",password1)
                    editor.putBoolean("saved", true)
                    editor.apply()
                }
                var myIntent = Intent(this, Headlines ::class.java)
                startActivity(myIntent)
                //Toast.makeText(getApplicationContext(),"Go ahead!", Toast.LENGTH_LONG).show()
            }
            else{
                Toast.makeText(getApplicationContext(),"Invalid username or password!", Toast.LENGTH_LONG).show()
            }
        }
    }
}