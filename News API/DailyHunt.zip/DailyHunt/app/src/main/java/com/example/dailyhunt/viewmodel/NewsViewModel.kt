package com.example.dailyhunt.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.dailyhunt.model.Content
import com.example.dailyhunt.networking.NewsRepository
import com.example.dailyhunt.networking.NewsRepository.Companion.getArticles

class NewsViewModel : ViewModel() {

    companion object{
        var mutableLiveData: MutableLiveData<Content> = MutableLiveData<Content>()

        fun getNewsRepository(): LiveData<Content?>? {

            mutableLiveData = getArticles("us","business")

            return mutableLiveData
        }
    }
}