package com.example.dailyhunt.model
import com.google.gson.annotations.SerializedName

data class Content (
    val status : String,
    val totalResults : Int,
    @SerializedName("articles")
    val myArticles : List<Article>
)