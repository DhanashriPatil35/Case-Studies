package com.example.assignment2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.text.SimpleDateFormat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //http://newsapi.org/v2/top-headlines?apiKey=1b8559d1dee8466db971aec61f0dcd1b&country=us&category=business

        val retrofit = Retrofit.Builder()
                .baseUrl("http://newsapi.org/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()

        val api = retrofit.create(ApiService::class.java)

        api.getArticles("us","business").enqueue(object : Callback<Article>{
            override fun onFailure(call: Call<Article>, t: Throwable) {
                println("onFailure method called...")
            }

            override fun onResponse(call: Call<Article>, response: Response<Article>) {
                println("onResponse method called...")
                showData(response.body()!!.myArticle)
            }
        })
    }

   private fun showData(articles : List<selectedArticle>){
        myRecyclerView.apply {
            var myRecyclerView = findViewById<RecyclerView>(R.id.myRecyclerView) as RecyclerView
            myRecyclerView.layoutManager = LinearLayoutManager(this@MainActivity, RecyclerView.VERTICAL,false)
            myRecyclerView.adapter = MyAdaptor(context,articles)
        }

    }
}