package com.example.assignment2

import com.google.gson.annotations.SerializedName

data class Article(
    val status : String,
    val totalResults : Int,
    @SerializedName("articles")
    val myArticle : List<selectedArticle>

)

data class selectedArticle(
    @SerializedName("source")
    val mySource : source,
    val author : String,
    val title : String,
    val description : String,
    val publishedAt : String,
    val content : String,
    val url : String,
    val urlToImage : String

)

data class source(
    val id : String,
    val name : String
)
