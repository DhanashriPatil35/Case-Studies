package com.example.assignment2

import android.content.Context
import android.os.Bundle
import android.content.Intent
import android.view.LayoutInflater
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.my_layout.view.*

class MyAdaptor(private val context: Context, val articles : List<selectedArticle>) : RecyclerView.Adapter<MyAdaptor.MyViewHolder>() {

    class MyViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val source : TextView = itemView.source
        val name : TextView = itemView.name
        val image : ImageView = itemView.imageView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var v = LayoutInflater.from(parent.context).inflate(R.layout.my_layout,parent, false)
        return MyViewHolder(v)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val article = articles[position]
        holder.source.setText(article.mySource.name)
        holder.name.setText(article.title)
        Glide.with(context).load(article.urlToImage).into(holder.image)

        holder.itemView.setOnClickListener {

            var intent = Intent(context,ShowContents::class.java)
            intent.putExtra("URL",article.url)
            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return articles.size
    }

}
