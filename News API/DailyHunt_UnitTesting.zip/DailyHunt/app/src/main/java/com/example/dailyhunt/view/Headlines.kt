package com.example.dailyhunt.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dailyhunt.R
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dailyhunt.adaptor.HeadlinesAdaptor
import com.example.dailyhunt.model.Article
import com.example.dailyhunt.networking.NewsRepository
import com.example.dailyhunt.networking.RetrofitService
import com.example.dailyhunt.viewmodel.NewsViewModel
import kotlinx.android.synthetic.main.activity_headlines.*

class Headlines : AppCompatActivity() {

    var myViewModel = NewsViewModel(NewsRepository())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_headlines)

        myViewModel.getNewsRepository()?.observe(this, Observer { responseArticle ->

            if (responseArticle != null) {
                showData(responseArticle.myArticles)
            }
            else{
                println(responseArticle)
            }
        }
        )
    }

    private fun showData(articles : ArrayList<Article>){
        myRecyclerView.apply {
            var myRecyclerView = findViewById<RecyclerView>(R.id.myRecyclerView) as RecyclerView
            myRecyclerView.layoutManager = LinearLayoutManager(this@Headlines, RecyclerView.VERTICAL,false)
            myRecyclerView.adapter = HeadlinesAdaptor(context,articles)
        }
    }
}