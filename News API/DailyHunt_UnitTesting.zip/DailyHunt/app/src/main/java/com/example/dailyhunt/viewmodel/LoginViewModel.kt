package com.example.dailyhunt.viewmodel

class LoginViewModel {

    fun validation(username:String, password: String): Boolean{
        if((username == "Admin" && password == "123") || (username == "Dhanashri" && password == "111")){
            return true
        }else{
            return false
        }
    }
}