package com.example.dailyhunt.model
import com.google.gson.annotations.SerializedName

data class Content (
    var status : String,
    var totalResults : Int,
    @SerializedName("articles")
    var myArticles : ArrayList<Article>
)