package com.example.dailyhunt.model

data class Source(
    var id : String,
    var name : String
)