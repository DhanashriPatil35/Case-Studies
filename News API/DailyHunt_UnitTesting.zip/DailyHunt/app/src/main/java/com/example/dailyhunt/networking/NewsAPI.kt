package com.example.dailyhunt.networking

import com.example.dailyhunt.model.Content
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

//http://newsapi.org/v2/top-headlines?apiKey=1b8559d1dee8466db971aec61f0dcd1b&country=us&category=business
const val API_KEY = "1b8559d1dee8466db971aec61f0dcd1b"

interface NewsAPI {
    @GET("top-headlines?apiKey=$API_KEY")
    fun getArticles(@Query("country") _country: String,
                    @Query("category") _category: String) : Call<Content>
}