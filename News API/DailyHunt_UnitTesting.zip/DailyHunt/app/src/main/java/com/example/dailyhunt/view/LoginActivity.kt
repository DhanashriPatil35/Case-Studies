package com.example.dailyhunt.view

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.dailyhunt.R
import com.example.dailyhunt.sharedpreferences.MySharedPreference
import com.example.dailyhunt.viewmodel.LoginViewModel
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        var myPreferences = MySharedPreference()
        val sharedPreferences: SharedPreferences = getSharedPreferences(myPreferences.sharedPrefFile,
            Context.MODE_PRIVATE)

        myPreferences.setupSharedPreference(sharedPreferences)

        username.setText(myPreferences._sharedUsername)
        password.setText(myPreferences._sharedPassword)

        var myLoginViewModel = LoginViewModel()

        save.setOnClickListener(){
            var username1 = username.text.toString()
            var password1 = password.text.toString()

            if(myLoginViewModel.validation(username1,password1)){

                if(saveDetails.isChecked()){
                    myPreferences.saveDetails(username1,password1)
                }
                var myIntent = Intent(this, Headlines ::class.java)
                startActivity(myIntent)
            }
            else{
                Toast.makeText(getApplicationContext(),"Invalid username or password!", Toast.LENGTH_LONG).show()
            }
        }
    }
}