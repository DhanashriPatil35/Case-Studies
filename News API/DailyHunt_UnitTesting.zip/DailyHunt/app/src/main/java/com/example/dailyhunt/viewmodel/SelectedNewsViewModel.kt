package com.example.dailyhunt.viewmodel

class SelectedNewsViewModel {
}