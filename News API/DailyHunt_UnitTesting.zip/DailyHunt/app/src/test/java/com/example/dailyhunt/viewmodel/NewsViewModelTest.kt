package com.example.dailyhunt.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import com.example.dailyhunt.model.Article
import com.example.dailyhunt.model.Content
import com.example.dailyhunt.model.Source
import com.example.dailyhunt.networking.NewsRepository
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.Mockito.mock
import org.mockito.junit.MockitoJUnit

@RunWith(JUnit4::class)
class NewsViewModelTest{

    @Mock
    lateinit var source1: Source

    @Mock
    lateinit var source2: Source

    @Mock
    lateinit var article1: Article

    @Mock
    lateinit var article2: Article

    @Mock
    lateinit var content: Content

    @Mock
    lateinit var myMutableData: MutableLiveData<Content>


    @get:Rule
    val rule = InstantTaskExecutorRule()

    @Rule @JvmField
    public var mockitoRule = MockitoJUnit.rule()

    @Test
    fun testNewsViewModel_returnsMutableLiveData() {

        source1 = Source("10","NBC News")
        source2 = Source("5","CNBC")

        article1 = Article(source1,
            "Lauren Levy, Shop TODAY",
            "Cyber Monday bestsellers: Best deals, top selling products we've covered - NBC News",
            "See the best deals and most purchased products of Cyber Monday 2020 that NBC covered, including air fryers, Dyson vacuums, Echelon bikes and more.",
            "2020-11-30T22:55:00Z",
            "More than halfway through Cyber Monday, were seeing some reader favorites return in scores and a few surprising trends otherwise. Just like the most popular Black Friday deals we covered, the preferr… [+3237 chars]",
            "https://www.nbcnews.com/shopping/cyber-monday/cyber-monday-bestsellers-n1249405",
            "https://media2.s-nbcnews.com/j/newscms/2020_49/3431722/201129-shopping-bfcm-faves-2x1-jm-1211_e659983a24273482f78a01203954ee52.nbcnews-fp-1200-630.jpg")

        article2 = Article(source2,
            "Fred Imbert",
            "Dow futures rise more than 200 points after Wall Street wraps up historically strong month - CNBC",
            "U.S. stock futures rose on Monday night after the major averages notched sharp monthly gains for November.",
            "2020-11-30T23:00:00Z",
            "U.S. stock futures rose on Monday night after the major averages notched sharp monthly gains for November.\\r\\nDow Jones Industrial Average futures traded 236 points higher. S&amp;P 500 and Nasdaq 100 f… [+2393 chars]",
            "https://www.cnbc.com/2020/11/30/stock-market-futures-open-to-close-news.html",
            "https://image.cnbcfm.com/api/v1/image/106779216-1605023251644-106779216-1604512335360NYSE-Trading-Floor-OB-Photo-201104-PRESS13-JPG.jpg?v=1605023277")


        val arrayList = ArrayList<Article>()
        arrayList.add(article1)
        arrayList.add(article2)

        content = Content("ok",22, arrayList)

        myMutableData = MutableLiveData<Content>()
        myMutableData.value = content

        val mymock : NewsRepository = mock(NewsRepository()::class.java)
        `when`(mymock.getArticles("us","business")).thenReturn(myMutableData)

        val test: NewsViewModel = NewsViewModel(mymock)
        var mydata : MutableLiveData<Content> =  test.getNewsRepository()
        assertNotNull(mydata.value)
    }

    @Test
    fun testNewsViewModel_returnsNull() {

        myMutableData = MutableLiveData<Content>()
        myMutableData.value = null

        val mymock : NewsRepository = mock(NewsRepository()::class.java)
        `when`(mymock.getArticles("us","business")).thenReturn(myMutableData)

        val test: NewsViewModel = NewsViewModel(mymock)
        var mydata : MutableLiveData<Content> =  test.getNewsRepository()
        assertNull(mydata.value)

    }
}