package com.example.dailyhunt.viewmodel

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class LoginViewModelTest{

    lateinit var test: LoginViewModel

    @Before
    fun setUp() {
        test = LoginViewModel()
    }

    @Test
    fun returnsTrueForAuthorizedUser_1(){
        var flag : Boolean = test.validation("Dhanashri","111")
        assertEquals(flag,true)
    }

    @Test
    fun returnsTrueForAuthorizedUser_2(){
        var flag : Boolean = test.validation("Admin","123")
        assertEquals(flag,true)
    }

    @Test
    fun returnsFalseForUnauthorizedUser_1(){
        var flag : Boolean = test.validation("Tejaswi","123")
        assertEquals(flag,false)
    }

    @Test
    fun returnsFalseForUnauthorizedUser_2(){
        var flag : Boolean = test.validation("Tejaswi","111")
        assertEquals(flag,false)
    }
}