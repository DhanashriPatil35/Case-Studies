package com.example.dailyhunt.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import com.example.dailyhunt.R

class SelectedNews : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_selected_news)

        val url = intent.getStringExtra("URL")
        if (url != null) {
            findViewById<WebView>(R.id.myView).loadUrl(url)
        }else{
            println("news url value is null")
        }
    }
}