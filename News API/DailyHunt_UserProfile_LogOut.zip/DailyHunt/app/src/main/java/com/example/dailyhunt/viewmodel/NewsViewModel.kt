package com.example.dailyhunt.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.dailyhunt.model.Content
import com.example.dailyhunt.networking.NewsRepository

class NewsViewModel(myRepo : NewsRepository) : ViewModel() {

        var myRepo1 = myRepo
        var mutableLiveData: MutableLiveData<Content> = MutableLiveData<Content>()

        fun getNewsRepository(): MutableLiveData<Content> {

            mutableLiveData = myRepo1.getArticles("us","business")
            return mutableLiveData
        }
}