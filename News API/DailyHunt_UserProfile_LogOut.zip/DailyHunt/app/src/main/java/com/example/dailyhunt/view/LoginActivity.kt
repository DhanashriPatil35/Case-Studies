package com.example.dailyhunt.view

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.dailyhunt.R
import com.example.dailyhunt.sharedpreferences.MySharedPreference
import com.example.dailyhunt.viewmodel.LoginViewModel
import kotlinx.android.synthetic.main.activity_login.*
import java.util.regex.Pattern


class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        var myPreferences = MySharedPreference()
        val sharedPreferences: SharedPreferences = getSharedPreferences(myPreferences.sharedPrefFile,
            Context.MODE_PRIVATE)

        myPreferences.setupSharedPreference(sharedPreferences)

        username.setText(myPreferences._sharedUsername)
        password.setText(myPreferences._sharedPassword)
        email.setText(myPreferences._sharedEmail)

        var myLoginViewModel = LoginViewModel()

        save.setOnClickListener(){
            var username1 = username.text.toString()
            var password1 = password.text.toString()
            var email1 = email.text.toString()

            val pattern: Pattern = Patterns.EMAIL_ADDRESS
            println(pattern.matcher(email1).matches())

            if(myLoginViewModel.isValidUser(username1,password1,email1)){
                if(saveDetails.isChecked()){
                    myPreferences.saveDetails(username1,password1,email1)
                }
                var myIntent = Intent(this, Headlines ::class.java)
                myIntent.putExtra("Name", username1)
                myIntent.putExtra("Email", email1)
                startActivity(myIntent)
            }
            else{
                Toast.makeText(getApplicationContext(),"Invalid username or password!", Toast.LENGTH_LONG).show()
            }
        }
    }
}