package com.example.dailyhunt.view

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.dailyhunt.R
import com.example.dailyhunt.sharedpreferences.MySharedPreference
import kotlinx.android.synthetic.main.activity_user_profile.*
import java.io.FileNotFoundException
import java.io.InputStream

class UserProfileActivity : AppCompatActivity() {
    companion object{
        var REQUEST_CODE_PICTURE= 101
        val REQUEST_CODE_GET_IMAGE = 101
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_PICTURE && resultCode == Activity.RESULT_OK) {
            if (data == null) {
                println("----NULL----")
                return
            }
            try {
                println("----setting photo----")
                val inputStream: InputStream? = contentResolver.openInputStream(data.data!!)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                profilePhoto.setImageBitmap(bitmap)
            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)

        var intent = intent
        var myname = intent.getStringExtra("Name")
        var myemail = intent.getStringExtra("Email")

        val profileName: TextView = findViewById(R.id.name)
        val profileEmail: TextView = findViewById(R.id.email)

        profileName.setText(myname)
        profileEmail.setText(myemail)

        profilePhoto.setOnClickListener(){
            val pickIntent = Intent()
            pickIntent.type = "image/*"
            pickIntent.action = Intent.ACTION_GET_CONTENT
            val takePhotoIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            val pickTitle = "Take or select a photo"
            val chooserIntent = Intent.createChooser(pickIntent, pickTitle)
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(takePhotoIntent))
            startActivityForResult(chooserIntent, REQUEST_CODE_GET_IMAGE)

        }

        logout.setOnClickListener(){
            var myPreferences = MySharedPreference()
            val sharedPreferences: SharedPreferences = getSharedPreferences(myPreferences.sharedPrefFile,
                Context.MODE_PRIVATE)
            myPreferences.setupSharedPreference(sharedPreferences)
            myPreferences.clearDetails()

            var myIntent = Intent(this, LoginActivity ::class.java)
            myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(myIntent)
        }
    }
}