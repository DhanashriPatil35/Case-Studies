package com.example.dailyhunt.viewmodel

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class LoginViewModelTest{

    lateinit var test: LoginViewModel

    @Before
    fun setUp() {
        test = LoginViewModel()
    }

    @Test
    fun returnsTrueForAuthorizedUser_1(){
        var flag : Boolean = test.isValidUser("Dhanashri Patil","111","dhanashri@gmail.com")
        assertEquals(flag,true)
    }

    @Test
    fun returnsTrueForAuthorizedUser_2(){
        var flag : Boolean = test.isValidUser("Admin","123","admin@gmail.com")
        assertEquals(flag,true)
    }

    @Test
    fun returnsFalseForInvalisUsername(){
        var flag : Boolean = test.isValidUser("Tejaswi","123","tejaswi@gmail.com")
        assertEquals(flag,false)
    }

    @Test
    fun returnsFalseForInvalidPassword(){
        var flag : Boolean = test.isValidUser("Dhanashri Patil","123","dhanashri@gmail.com")
        assertEquals(flag,false)
    }

    @Test
    fun returnsFalseForInvalidEmail(){
        var flag : Boolean = test.isValidUser("Admin","123","admin@gmail")
        assertEquals(flag,false)
    }
}